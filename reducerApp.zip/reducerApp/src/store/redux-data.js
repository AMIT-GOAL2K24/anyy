
import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./counter-slicer";
import authReducer from "./auth-slicer"



const store = configureStore({
    reducer: {counter: counterReducer,
               auth: authReducer}
});




export default store;