import { createSlice } from "@reduxjs/toolkit"

const initialState = {
    counter:5,
    showCounter: true,
}

const counterReducer = createSlice({
    name:'counter',
    initialState:initialState,
    reducers:{
        increase(state){
           
                state.counter= state.counter + 1
            
        },
        decrease(state){
                state.counter= state.counter - 1
        },
        change(state, action){
            state.counter= state.counter + action.payload
        },
        toggleCounter(state){
            state.showCounter = !state.showCounter
        }
    }
})

export const counterAction = counterReducer.actions

export default counterReducer.reducer;
