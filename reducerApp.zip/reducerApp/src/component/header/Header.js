import React from 'react'
import style from "./Header.module.css"
import Home from '../Home/Home'
import {  useDispatch, useSelector } from 'react-redux'
import Login from '../Login/Login'
import { authAction } from '../../store/auth-slicer'


const Header = () => {
    const authBool = useSelector(state => state.auth.isAuth);
    console.log(authBool)
    const dispatch = useDispatch();
  return (
    <>
    <div className={style.container}>
        <div className={style.logo}>
            My Logo
        </div>
        {authBool && <div className={style.tabs}>
            <div className={style.downloads}>Downloads</div>
            <div className={style.products}>
                Products
            </div>
            <div className={style.logout}>
                <button onClick={()=>dispatch(authAction.logout())}>Logout</button>
            </div>
        </div>}
    </div>
    {authBool && <Home/>}
    {!authBool && <Login/>}

    </>
  )
}

export default Header