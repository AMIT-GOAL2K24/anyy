import Counter from "./component/Counter/Counter";
import Header from "./component/header/Header";


function App() {
  return (
    <>
    <Header/>
     <Counter/>
    </>
   
    
  );
}

export default App;
