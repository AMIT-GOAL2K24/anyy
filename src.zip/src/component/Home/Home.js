import React from 'react'
import style from "./Home.module.css"

export const Home = () => {
  return (
    <div className={style.container}>
        Welcome to Home Page
    </div>
  )
}


export default Home;