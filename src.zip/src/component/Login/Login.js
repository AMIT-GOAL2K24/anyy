import React from 'react'
import style from "./Login.module.css"
import { useDispatch } from 'react-redux'
import { authAction } from '../../store/redux-data';

const Login = () => {
    const dispatch = useDispatch();
    const submitHandler = (e) => {
        e.preventDefault();
        dispatch(authAction.login());

    }
  return (
    <div className={style.container}>
        <form onSubmit={ submitHandler}>
            <div>
                <lable>Email Id</lable>
                <input type="email" placeholder='Enter email'/>
            </div>

            <div>
                <lable>Password</lable>
                <input type="password" placeholder='Enter password'/>
            </div>

            <button type="submit">Login</button>
        </form>
    </div>
  )
}

export default Login