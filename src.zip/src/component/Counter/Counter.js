import React from 'react'
import style from "./Counter.module.css"
import { useDispatch, useSelector } from 'react-redux'
import { counterAction } from '../../store/redux-data'

const Counter = () => {
    let counterValue = useSelector( state => state.counter.counter);
    let dispatch = useDispatch();
    let showCount = useSelector(state => state.counter.showCounter)
    
  return (
    <div className={style.container}>
        <div className={style.counterContainer}>

       <div className={style.counterTitle}>
        <h1>Counter</h1> </div>

      { showCount && <div className={style.countValue}>  {counterValue}</div>}

       <div className={style.buttonContainer}>
        <button onClick={()=> dispatch( counterAction.increase())}>Inc</button>
        <button onClick={()=> dispatch(counterAction.change(5))}> Inc by + 5</button>
        <button onClick={()=> dispatch(counterAction.decrease())}>Dec</button>
       </div>
       <button className={style.toggle} onClick={ () => dispatch(counterAction.toggleCounter())}>Toggle</button>
       </div>
    </div>
  )
}

export default Counter