
import { createSlice, configureStore } from "@reduxjs/toolkit";

const initialState = {
    counter:5,
    showCounter: true,
}

const counterReducer = createSlice({
    name:'counter',
    initialState:initialState,
    reducers:{
        increase(state){
           
                state.counter= state.counter + 1
            
        },
        decrease(state){
                state.counter= state.counter - 1
        },
        change(state, action){
            state.counter= state.counter + action.payload
        },
        toggleCounter(state){
            state.showCounter = !state.showCounter
        }
    }
})

const initialAuthState = { isAuth : true }

const authReducer = createSlice({
    name:"auth",
    initialState:initialAuthState,
    reducers:{
        login(state){
            state.isAuth = true
        },
        logout(state){
            state.isAuth = false
        }
    }
})

const store = configureStore({
    reducer: {counter: counterReducer.reducer,
               auth: authReducer.reducer}
});

 export const counterAction = counterReducer.actions
 export const authAction = authReducer.actions

export default store;